<?php

include_once("config.php");

insert_order();

?>